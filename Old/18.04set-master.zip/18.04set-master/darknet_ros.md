# 카메라를 사용하는 프로그램 예시 
$ roslaunch openni2_launch openni2.launch # darknet 실행 명령어 
$ roslaunch darknet_ros darknet_ros.launch

출처: https://taemian.tistory.com/entry/ROS-1-n-darknetros를-활용한-Yolo-v3-사용법?category=832732 [Taemian]


darknet > makefile 제일위에 사용 하면 1 안하면 0  치면 됨
