ps : process 상태를 볼 때 사용하는 명령어
ps -l : prosess list 보는 것
